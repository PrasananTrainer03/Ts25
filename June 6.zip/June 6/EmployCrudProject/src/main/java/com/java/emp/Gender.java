package com.java.emp;

public enum Gender {

	MALE, FEMALE
}
