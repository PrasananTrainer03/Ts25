package com.java.gen;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Welcome to Java Programming...");
		System.out.println(sb);
		sb.append("\r\n Trainer is Prasanna...");
		System.out.println(sb);
	}
}
