package com.java.gen;

public class StrExample {

	public static void main(String[] args) {
		String str = "Hello ";
		str.concat("World...");
		System.out.println(str);
	}
}
